package mtproto

//go:generate errorgen
