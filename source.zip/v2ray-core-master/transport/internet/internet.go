package internet

//go:generate errorgen
